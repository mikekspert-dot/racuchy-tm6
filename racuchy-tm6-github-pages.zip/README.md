# Racuchy z jabłkami – Thermomix TM6

Prosta strona z przepisem przygotowana do publikacji przez GitHub Pages
i wykorzystania jako publiczny URL do importu przepisu.

## GitHub Pages
Po utworzeniu repozytorium:
1. Settings → Pages
2. Source: Deploy from a branch
3. Branch: main / root
4. Save

Adres będzie miał postać:
https://NAZWA-UZYTKOWNIKA.github.io/racuchy-tm6/
